<?php
    include_once(dirname(__DIR__) . '/templates/tpl_common.php');

    if (!isset($_SESSION['email']))
        die(header('Location: ./login.php'));

    draw_header("Добавьте питомца", array('new_pet.css'), array('new-pet.js'));
?>

<section class="pet-container">    
    <form method="post" action="../actions/pet/action_new_pet.php" enctype="multipart/form-data">
        <input hidden name="csrf" value="<?= $_SESSION['csrf'] ?>">
        <section class="add-pet-image">
            <h2 class="large-text">Питомец</h2>
            <section id="images-preview"></section>
            <label for="pet-image" class="custom-file-upload"></label>
            <input type="file" name="pet-image[]" id="pet-image" onchange="previewImages(this);" multiple>
        </section>

        <section class="pet-info">
            <label for="name">Кличка:</label>
            <input type="text" name="name" placeholder="Китти, Боб, Джек..." pattern="^[а-яёА-ЯЁa-zA-Z-'À-ú ]+$" onkeyup="checkName()" onBlur="checkName()" oninvalid="invalidName(this);" required>
            <label for="species">Вид:</label>
            <input type="text" name="species" placeholder="Собака, кот, попугай, рыбка..." pattern="^[а-яёА-ЯЁa-zA-Z-'À-ú ]+$" onkeyup="checkSpecies()" onBlur="checkSpecies()" oninvalid="invalidSpecies(this);" required>
            <label for="age">Возраст:</label>
            <input type="text" name="age" placeholder="5 лет, 8 месяцев, 3 недели..." pattern="^[а-яёА-ЯЁa-zA-ZÀ-ú\d' ]+$" onkeyup="checkAge()" onBlur="checkAge()" oninvalid="invalidAge(this);">
            <label for="color">Цвет:</label>
            <input type="text" name="color" placeholder="Коричневый, белый, зелёный, оранжевый..." pattern="^[а-яёА-ЯЁa-zA-Z-'À-ú ]+$" onkeyup="checkColor()" onBlur="checkColor()" oninvalid="invalidColor(this);">
            <label for="location">Адрес:</label>
            <input type="text" name="location" placeholder="Укажите адрес..." pattern="^[а-яёА-ЯЁa-zA-ZÀ-ú\d' ]+$$" onkeyup="checkLocation()" onBlur="checkLocation()" oninvalid="invalidLocation(this);" required>
            <input type="submit" value="Добавить" class="large-text">
        </section>
    </form>
</section>

<?php
    draw_footer();
?>