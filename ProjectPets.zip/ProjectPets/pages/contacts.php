<?php

include_once(dirname(__DIR__) . '/templates/tpl_common.php');

draw_header("Контакты", array('contacts.css'));

?>

<div class = "contact_us">
    <p>
        Почта: 300denden300@gmail.com
    <p>
</div>
    
<?php
    draw_footer();
?>
    