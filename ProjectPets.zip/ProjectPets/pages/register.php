<?php

include_once(dirname(__DIR__) . '/templates/tpl_common.php');

if (isset($_SESSION['email']))
    die(header('Location: ./profile.php'));

draw_header("Регистрация", NULL, array("register.js"));
?>

<section class="user-form">
    <form method="post" action="../actions/user/action_register.php">
        <input hidden name="csrf" value="<?= $_SESSION['csrf'] ?>">
        <label for="name">Имя:</label>
        <input type="text" name="name" placeholder="Ваше имя" pattern="^[a-zA-Z-'À-ú ]+$" onkeyup="checkName()" onBlur="checkName()" oninvalid="invalidName(this);" required>
        <label for="phone">Номер телефона:</label>
        <input type="tel" name="phone" placeholder="Ваш номер" pattern="[9]{1}[1,2,3,6]{1}[0-9]{7}" onkeyup="checkPhone()" onBlur="checkPhone()" oninvalid="invalidPhone(this);" required>
        <label for="email">Email:</label>
        <input type="email" name="email" placeholder="Электронная почта" pattern="(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)" onkeyup="checkEmail()" onBlur="checkEmail()" oninvalid="invalidEmail(this);" required>
        <label for="password">Пароль:</label>
        <input type="password" name="password" placeholder="Пароль" pattern="^\S*(?=\S{8,})(?=\S*[a-z])(?=\S*[A-Z])(?=\S*[\d])\S*$" onkeyup="checkPassword()" onBlur="checkPassword()" oninvalid="invalidPassword(this);" required>
        <input type="submit" value="Зарегистрироваться" class="large-text">
    </form>

    <footer>
        <p>Уже есть аккаунт?<a href="login.php">Войти</a></p>
    </footer>
</section>


<?php
    draw_footer();
?>