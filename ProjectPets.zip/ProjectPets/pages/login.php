<?php

include_once(dirname(__DIR__) . '/templates/tpl_common.php');

if (isset($_SESSION['email']))
    die(header('Location: ./profile.php'));

draw_header("Вход");
?>

<section class="user-form">
    <form method="post" action="../actions/user/action_login.php">
        <input hidden name="csrf" value="<?= $_SESSION['csrf'] ?>">
        <label for="email">Электронная почта:</label>
        <input type="email" name="email" placeholder="Электронная почта" required>
        <label for="password">Пароль:</label>
        <input type="password" name="password" placeholder="Пароль" required>
        <input type="submit" value="Войти" class="large-text">
    </form>


    <footer>
        <p>У Вас нет аккаунта? <a href="register.php">Зарегистрироваться</a></p>
    </footer>
</section>

<?php
draw_footer();
?>