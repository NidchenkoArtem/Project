<?php

include_once(__DIR__ . '/templates/tpl_common.php');

draw_header(NULL); ?>

<div class="adopt">
    <section class="top-banner">
        <img src="../css/images/main_pag.png" />
        <a href="/pages/adopt-list.php">
            <h3 class="large-text">Найди своего друга по жизни!</h3>
        </a>
    </section>
</div>
